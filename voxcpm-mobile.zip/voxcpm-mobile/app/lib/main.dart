import 'dart:convert';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const VoxApp());

class VoxApp extends StatelessWidget {
  const VoxApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VoxCPM',
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        darkTheme: ThemeData(
          colorSchemeSeed: Colors.indigo,
          brightness: Brightness.dark,
          useMaterial3: true,
        ),
        home: const HomePage(),
      );
}

enum Mode { basic, design, clone }

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _server = TextEditingController();
  final _apiKey = TextEditingController();
  final _text = TextEditingController();
  final _style = TextEditingController();
  final _transcript = TextEditingController();
  final _player = AudioPlayer();

  Mode _mode = Mode.basic;
  PlatformFile? _ref;
  bool _busy = false;
  bool _playing = false;
  String? _error;
  String? _outPath;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _server.dispose();
    _apiKey.dispose();
    _text.dispose();
    _style.dispose();
    _transcript.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    _server.text = p.getString('server') ?? 'http://192.168.1.10:8000';
    _apiKey.text = p.getString('key') ?? '';
    if (mounted) setState(() {});
  }

  Future<void> _pickReference() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (r != null && r.files.single.path != null) {
      setState(() => _ref = r.files.single);
    }
  }

  Future<void> _generate() async {
    final base = _server.text.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty || _text.text.trim().isEmpty) {
      setState(() => _error = 'Enter the server address and some text.');
      return;
    }
    if (_mode == Mode.clone && _ref?.path == null) {
      setState(() => _error = 'Pick a reference audio file first.');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('server', base);
      await prefs.setString('key', _apiKey.text.trim());

      final req = http.MultipartRequest('POST', Uri.parse('$base/tts'))
        ..fields['text'] = _text.text.trim();
      if (_mode != Mode.basic && _style.text.trim().isNotEmpty) {
        req.fields['voice_description'] = _style.text.trim();
      }
      if (_mode == Mode.clone) {
        req.files.add(
            await http.MultipartFile.fromPath('reference', _ref!.path!));
        if (_transcript.text.trim().isNotEmpty) {
          req.fields['transcript'] = _transcript.text.trim();
        }
      }
      final key = _apiKey.text.trim();
      if (key.isNotEmpty) req.headers['x-api-key'] = key;

      final res = await req.send().timeout(const Duration(minutes: 5));
      final bytes = await res.stream.toBytes();
      if (res.statusCode != 200) {
        throw Exception(
            'Server error ${res.statusCode}: ${utf8.decode(bytes, allowMalformed: true)}');
      }

      final dir = await getTemporaryDirectory();
      final file = File(
          '${dir.path}/voxcpm_${DateTime.now().millisecondsSinceEpoch}.wav');
      await file.writeAsBytes(bytes);
      _outPath = file.path;

      await _player.stop();
      await _player.play(DeviceFileSource(file.path));
      if (mounted) setState(() => _playing = true);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _togglePlay() async {
    if (_outPath == null) return;
    if (_playing) {
      await _player.pause();
      setState(() => _playing = false);
    } else {
      if (_player.state == PlayerState.paused) {
        await _player.resume();
      } else {
        await _player.play(DeviceFileSource(_outPath!));
      }
      setState(() => _playing = true);
    }
  }

  Future<void> _save() async {
    if (_outPath == null) return;
    final bytes = await File(_outPath!).readAsBytes();
    final saved = await FilePicker.platform.saveFile(
      dialogTitle: 'Save audio',
      fileName: 'voxcpm.wav',
      bytes: bytes,
    );
    if (saved != null && mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Saved')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VoxCPM')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _server,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Server address',
                hintText: 'http://192.168.1.10:8000',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _apiKey,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'API key (optional)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            SegmentedButton<Mode>(
              segments: const [
                ButtonSegment(value: Mode.basic, label: Text('Basic')),
                ButtonSegment(value: Mode.design, label: Text('Design')),
                ButtonSegment(value: Mode.clone, label: Text('Clone')),
              ],
              selected: {_mode},
              onSelectionChanged: (s) => setState(() => _mode = s.first),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _text,
              minLines: 4,
              maxLines: 8,
              decoration: const InputDecoration(
                labelText: 'Text to speak',
                border: OutlineInputBorder(),
              ),
            ),
            if (_mode != Mode.basic) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _style,
                decoration: InputDecoration(
                  labelText: _mode == Mode.design
                      ? 'Voice description'
                      : 'Style (optional)',
                  hintText: _mode == Mode.design
                      ? 'A young woman, gentle and sweet voice'
                      : 'slightly faster, cheerful tone',
                  border: const OutlineInputBorder(),
                ),
              ),
            ],
            if (_mode == Mode.clone) ...[
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _pickReference,
                icon: const Icon(Icons.audio_file),
                label: Text(_ref?.name ?? 'Pick reference audio (WAV works best)'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _transcript,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Reference transcript (optional, for closest clone)',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _busy ? null : _generate,
              icon: _busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.graphic_eq),
              label: Text(_busy ? 'Generating…' : 'Generate'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            if (_outPath != null) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  IconButton.filledTonal(
                    onPressed: _togglePlay,
                    icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
                  ),
                  const SizedBox(width: 8),
                  IconButton.outlined(
                    onPressed: _save,
                    icon: const Icon(Icons.download),
                    tooltip: 'Save to phone',
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
