"""VoxCPM2 text-to-speech HTTP server (used by the Android app)."""
import io
import os
import tempfile
import threading
from contextlib import asynccontextmanager
from typing import Optional

import soundfile as sf
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import Response
from voxcpm import VoxCPM

MODEL_ID = os.getenv("VOXCPM_MODEL", "openbmb/VoxCPM2")
API_KEY = os.getenv("API_KEY", "")  # optional; if set, the app must send it

state = {}
gpu_lock = threading.Lock()


@asynccontextmanager
async def lifespan(_: FastAPI):
    state["model"] = VoxCPM.from_pretrained(MODEL_ID, load_denoiser=False)
    yield


app = FastAPI(title="VoxCPM server", lifespan=lifespan)


@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL_ID}


@app.post("/tts")
def tts(
    text: str = Form(...),
    voice_description: str = Form(""),
    transcript: str = Form(""),
    cfg_value: float = Form(2.0),
    steps: int = Form(10),
    seed: int = Form(-1),
    reference: Optional[UploadFile] = File(None),
    x_api_key: str = Header(""),
):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(401, "Invalid API key")

    text = text.strip()
    if not text:
        raise HTTPException(400, "text is empty")

    model = state["model"]
    kwargs = dict(cfg_value=cfg_value, inference_timesteps=steps)
    if seed >= 0:
        kwargs["seed"] = seed

    tmp_path = None
    try:
        if reference is not None and reference.filename:
            suffix = os.path.splitext(reference.filename)[1] or ".wav"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
                f.write(reference.file.read())
                tmp_path = f.name
            kwargs["reference_wav_path"] = tmp_path
            if transcript.strip():  # "ultimate cloning": reference + exact transcript
                kwargs["prompt_wav_path"] = tmp_path
                kwargs["prompt_text"] = transcript.strip()

        # Voice design / style control: description in parentheses before the text
        if voice_description.strip() and not transcript.strip():
            text = f"({voice_description.strip()}){text}"

        with gpu_lock:
            wav = model.generate(text=text, **kwargs)

        buf = io.BytesIO()
        sf.write(buf, wav, model.tts_model.sample_rate, format="WAV")
        return Response(buf.getvalue(), media_type="audio/wav")
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, str(e))
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
