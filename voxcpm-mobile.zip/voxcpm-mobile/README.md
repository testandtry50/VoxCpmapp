# VoxCPM Mobile

Android app (Flutter) + small server for [VoxCPM2](https://github.com/OpenBMB/VoxCPM) text-to-speech.
The model runs on the server (needs an NVIDIA GPU); the phone app sends text and plays the audio.

## 1. Get the APK
1. Push this repo to GitHub (branch `main`).
2. Open the **Actions** tab → **Build APK** → wait for the green tick.
3. Open the run → **Artifacts** → download `voxcpm-apk` → unzip → install `app-release.apk`
   (allow "install unknown apps" when Android asks).

## 2. Run the server (on a PC / cloud GPU)
```bash
cd server
pip install -r requirements.txt
# optional: set a password the app must send
export API_KEY=choose-a-secret
uvicorn server:app --host 0.0.0.0 --port 8000
```
The first start downloads the model (several GB).

## 3. Use the app
Open the app, type the server address (e.g. `http://192.168.1.10:8000` on the same Wi-Fi),
add the API key if you set one, then pick a mode:
- **Basic** – plain text to speech
- **Design** – describe a voice ("A young woman, gentle and sweet voice")
- **Clone** – pick a reference clip (+ optional exact transcript for the closest match)

To reach the server from mobile data, use a tunnel (e.g. Cloudflare Tunnel or ngrok) and
paste its `https://` address in the app. Always set `API_KEY` if the server is public.
